
	<?php
	$query="SELECT * from users;";
			$polaczenie = @new mysqli("192.168.43.93", "root", "", "php3");
			$rezultat=@$polaczenie->query($query);
			echo "<style>table, th, td { border: 1px solid black;}</style>";
			
			
			echo "<h1>Uzytkownicy:</h1><br>";
			echo "<table><tr><th>ID:</th><th>Login:</th><th>Password:</th>";
			while($row = $rezultat->fetch_assoc()){
				 $json[] = $row;
				 echo "<tr><th>".$row['ID']."</th>"."<th>".$row['Login']."</th>"."<th>".$row['Password']."</th></tr>";
			}
			
			echo "</table><br><h1>Dane:</h1><br>";
			echo "<table><tr><th>ID:</th><th>Imie:</th><th>Nazwisko:</th><th>Opis:</th>";
				$query="SELECT * from dane;";
			$rezultat=@$polaczenie->query($query);
			while($row = $rezultat->fetch_assoc()){
				 $json[] = $row;
				  echo "<tr><th>".$row['ID']."</th>"."<th>".$row['Imie']."</th>"."<th>".$row['Nazwisko']."</th><th>".$row['Nazwisko']."</th></tr>";
			}
			$polaczenie->close();
		
		
		
		
		?>

