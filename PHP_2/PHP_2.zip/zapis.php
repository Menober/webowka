		<?php
		$_COOKIE['kolorek']=$_POST['kolorek'];
		header("Location: php2.php");
		?>
